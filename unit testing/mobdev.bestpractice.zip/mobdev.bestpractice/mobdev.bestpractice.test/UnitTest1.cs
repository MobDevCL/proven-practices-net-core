using NUnit.Framework;
using mobdev.bestpractice.domain;

namespace mobdev.bestpractice.test
{
    public class Tests_Account
    {

        


    }
}