//using Microsoft.VisualStudio.TestTools.UnitTesting;
using mobdev.bestpractice.domain;
using NUnit.Framework;
using System;

namespace mobdev.bestpractice.test
{
    public class Tests_FileProcess
    {
        [SetUp]
        public void Setup()
        {
        }

        
    }
}